alert('Just another demo');
document.getElementById("output3").innerHTML = "This is an external js script";

