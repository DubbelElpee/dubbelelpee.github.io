function meow(){
    
    document.getElementById("output2").innerHTML = "meow is called";

}

function arf(){
    document.getElementById("output2").innerHTML = "arf arf";

}