function myFunction() {
    document.getElementById("outpu3t").innerHTML ="Hi! I am method from an external script";
  }
/*
  function copyInfo(){
    //document.getElementById("output2").innerHTML = document.getElementById("name").innerHTML;
    document.getElementById("output2").innerHTML ="foo";
  }
  */